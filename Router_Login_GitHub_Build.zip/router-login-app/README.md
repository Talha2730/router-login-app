# Router Login Android APK
A minimal Android WebView app opening http://192.168.0.1/login.htm.

## Build without Android Studio
Upload all project files including `.github/workflows/build-apk.yml` to a new GitHub repository. Open Actions > Build Router Login APK > Run workflow. Download `Router-Login-APK` from the successful workflow run's Artifacts section and extract `app-debug.apk`.

Phone must be on the router Wi-Fi and router must use 192.168.0.1. Debug APK is for personal installation, not Play Store release. The app does not store credentials itself; router page behavior is controlled by the router.
